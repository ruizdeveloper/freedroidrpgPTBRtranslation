#!/bin/sh

# This file is part of Freedroid

# Freedroid is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# Freedroid is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with Freedroid; see the file COPYING. If not, write to the 
# Free Software Foundation, Inc., 59 Temple Place, Suite 330, Boston, 
# MA 02111-1307 USA

echo '[EN] Welcome to the FreeDroid RPG v0.15.1 PT-BR translation installer.'
echo 'Please make sure you are running this script as root and please read the LEIA ME file'
echo ''
echo '[PT-BR] Bem vindo ao instalador da traducao para PT-BR do FreeDroid RPG v0.15.1.'
echo 'Tenha certeza de que esta executando este script como root e por favor leia o arquivo de nome LEIA ME'
echo 'CTRL+C para abortar. Enter para prosseguir.'
read nothing
echo 'Iniciando instalacao.'
echo 'Verificando FreeDroid RPG...'
freepasta="/usr/share/games/freedroidrpg"
if [ ! -d "/usr/share/games/freedroidrpg" ]; then
	echo "Voce instalou o jogo? Se sim insira o caminho para a pasta 'freedroidrpg', caso contrario, CTRL+C para abortar:"
	read freepasta
fi
if [ ! -d "$freepasta/dialogs" ]; then
	echo "Nao foi encontrada a pasta de dialogos. Insira o caminho para a pasta 'freedroidrpg/dialogs', ou CTRL+C para abortar:"
	read freepasta
fi
echo 'Verificado.'
echo 'Traduzindo...'
cp -f -R -v "dialogs" "$freepasta"
if [ $? = 0 ];then
	echo "Dialogos traduzidos."
else
	echo "Erro ao copiar arquivos de dialogo."
fi

if [ ! -d "$freepasta/map" ]; then
	echo "Nao foi encontrada a pasta map. Insira o caminho para a pasta 'freedroidrpg/map', ou CTRL+C para abortar:"
	read freepasta
fi
cp -f -R -v "map" "$freepasta"
if [ $? = 0 ];then
	echo "SUCESSO: Traduzido para PT-BR."
else
	echo "FALHA: Erro ao copiar arquivos."
fi
echo 'Finalizado. Pressione Enter para sair...'
read nothing
