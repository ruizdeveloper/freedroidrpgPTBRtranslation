var group__FDnpc =
[
    [ "drop_dead", "group__FDnpc.html#ga4b3527ea73fb7711d3f93011c1638aa0", null ],
    [ "freeze", "group__FDnpc.html#ga8ea6e18086afe406aefa7802ec801c85", null ],
    [ "get_class", "group__FDnpc.html#ga46eaf0612019944899df0f2767247cf7", null ],
    [ "get_health", "group__FDnpc.html#gabe5d4f061a029036ea8bfd29e02f29eb", null ],
    [ "get_max_health", "group__FDnpc.html#gaed19ea5ecf25938cd67a2d01cf1ba011", null ],
    [ "get_name", "group__FDnpc.html#ga1bbf28aef8fb28a0e563fdf2b59d6f57", null ],
    [ "get_rush_tux", "group__FDnpc.html#gac45c3553b76f9c18004e18964bbe4b81", null ],
    [ "get_sensor", "group__FDnpc.html#ga0453f2358c77464e2480e4be63911afe", null ],
    [ "get_translated_name", "group__FDnpc.html#gacc02c2a1fcc07b9875042e015358b676", null ],
    [ "get_type", "group__FDnpc.html#ga46a65f43c5da519007754223e3bc9b1a", null ],
    [ "heal", "group__FDnpc.html#gaadbd8834a265ae130fad6295ba6ca276", null ],
    [ "is_dead", "group__FDnpc.html#ga2be0adc22a563e08254b741a6fcbb8fb", null ],
    [ "set_death_item", "group__FDnpc.html#gaf3e271b6ee091cdb9b841ed1e04e7e71", null ],
    [ "set_destination", "group__FDnpc.html#ga7f64e03ae95f90b9e1903466e6702073", null ],
    [ "set_name", "group__FDnpc.html#gaabd83f33e421ce057cbe9379039d663c", null ],
    [ "set_rush_tux", "group__FDnpc.html#gaf862aca467a6766e94ccb2da3dba6d93", null ],
    [ "set_state", "group__FDnpc.html#ga53a57be05fea2c516e1769093e4404e9", null ],
    [ "set_state", "group__FDnpc.html#ga9611c53dc978781fa4e757c6b89edcfd", null ],
    [ "teleport", "group__FDnpc.html#gae12fd63e4a735efc2d5f4675238fa60b", null ]
];